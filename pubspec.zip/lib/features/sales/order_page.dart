import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:bizpawa/models/product.dart';
import 'package:bizpawa/models/order_item.dart';
import 'package:bizpawa/core/state/business_state.dart';

import 'select_product_page.dart';

class OrderPage extends StatefulWidget {
  const OrderPage({super.key});

  @override
  State<OrderPage> createState() => _OrderPageState();
}

class _OrderPageState extends State<OrderPage> {
  DateTime _date = DateTime.now();
  String? _customer;
  bool _paid = true;
  int _discount = 0;
  String _note = '';

  final List<OrderItem> _items = [];

  /// ================= TOTAL CALCULATIONS =================
  int get subtotal =>
      _items.fold<int>(0, (sum, item) => sum + item.total);

  int get total {
    final value = subtotal - _discount;
    return value < 0 ? 0 : value;
  }

  /// ================= UI =================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Uza')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// CUSTOMER
            TextFormField(
              decoration:
                  const InputDecoration(labelText: 'Mteja (hiari)'),
              onChanged: (v) => _customer = v.trim(),
            ),

            const SizedBox(height: 12),

            /// DATE
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Tarehe ya Mauzo'),
              subtitle:
                  Text('${_date.day}/${_date.month}/${_date.year}'),
              trailing: const Icon(Icons.calendar_today),
              onTap: _pickDate,
            ),

            const Divider(),

            /// PAYMENT STATUS
            Row(
              children: [
                Expanded(
                  child: RadioListTile<bool>(
                    value: true,
                    groupValue: _paid,
                    title: const Text('Imelipiwa'),
                    onChanged: (_) =>
                        setState(() => _paid = true),
                  ),
                ),
                Expanded(
                  child: RadioListTile<bool>(
                    value: false,
                    groupValue: _paid,
                    title: const Text('Haijalipiwa'),
                    onChanged: (_) =>
                        setState(() => _paid = false),
                  ),
                ),
              ],
            ),

            const Divider(),

            /// ADD PRODUCT
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                icon: const Icon(Icons.add),
                label: const Text('Chagua Bidhaa / Huduma'),
                onPressed: _openProductPicker,
              ),
            ),

            const SizedBox(height: 16),

            /// ORDER ITEMS
            ..._items.map(_orderItemTile),

            if (_items.isNotEmpty) ...[
              const Divider(),

              /// DISCOUNT
              TextFormField(
                keyboardType: TextInputType.number,
                decoration:
                    const InputDecoration(labelText: 'Discount'),
                onChanged: (v) {
                  setState(() {
                    _discount = int.tryParse(v) ?? 0;
                  });
                },
              ),

              const SizedBox(height: 12),

              /// NOTE
              TextFormField(
                decoration:
                    const InputDecoration(labelText: 'Maelezo'),
                onChanged: (v) => _note = v,
              ),

              const SizedBox(height: 16),

              /// TOTAL
              Text(
                'Jumla: $total TZS',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 16),

              /// SAVE
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _saveOrder,
                  child: const Text('Hifadhi Mauzo'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// ================= HELPERS =================

  void _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );

    if (picked != null) {
      setState(() => _date = picked);
    }
  }

  void _openProductPicker() async {
    final product = await Navigator.push<Product>(
      context,
      MaterialPageRoute(
        builder: (_) => const SelectProductPage(),
      ),
    );

    if (product != null) {
      _showQuantityPopup(product);
    }
  }

  void _showQuantityPopup(Product product) {
    int qty = 1;

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(product.name),
        content: TextField(
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Idadi'),
          onChanged: (v) => qty = int.tryParse(v) ?? 1,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Ghairi'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _items.add(
                  OrderItem(product: product, quantity: qty),
                );
              });
              Navigator.pop(context);
            },
            child: const Text('Ongeza'),
          ),
        ],
      ),
    );
  }

  Widget _orderItemTile(OrderItem item) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            /// INFO
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.product.name,
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${item.quantity} × ${item.product.sellingPrice} TZS',
                    style: const TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),

            /// CONTROLS
            Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.remove),
                  onPressed: () {
                    setState(() {
                      if (item.quantity > 1) {
                        item.quantity--;
                      } else {
                        _items.remove(item);
                      }
                    });
                  },
                ),
                Text(
                  item.quantity.toString(),
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                IconButton(
                  icon: const Icon(Icons.add),
                  onPressed: () {
                    setState(() {
                      item.quantity++;
                    });
                  },
                ),
              ],
            ),

            const SizedBox(width: 8),

            /// TOTAL
            Text(
              '${item.total} TZS',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }

  void _saveOrder() {
    if (_items.isEmpty) return;

    if (!_paid && (_customer == null || _customer!.isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Kwa mauzo ya mkopo, tafadhali weka jina la mteja',
          ),
        ),
      );
      return;
    }

    final business = context.read<BusinessState>();

    for (final item in _items) {
      business.recordSale(
        product: item.product,
        quantity: item.quantity,
        discount: _discount,
        date: _date,
        paid: _paid,
      );
    }

    Navigator.pop(context);
  }
}
