import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:bizpawa/core/state/business_state.dart';
import 'package:bizpawa/models/product.dart';

class SelectProductPage extends StatelessWidget {
  const SelectProductPage({super.key});

  @override
  Widget build(BuildContext context) {
    final items = context.watch<BusinessState>().inventory;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Chagua Bidhaa / Huduma'),
      ),
      body: items.isEmpty
          ? const Center(
              child: Text(
                'Hakuna bidhaa au huduma bado.\nOngeza kwanza kwenye Inventory.',
                textAlign: TextAlign.center,
              ),
            )
          : ListView.builder(
              itemCount: items.length,
              itemBuilder: (context, index) {
                final item = items[index];

                return ListTile(
                  title: Text(item.name),
                  subtitle: Text(
                    item.unit == 'SERVICE'
                        ? 'Huduma'
                        : 'Stock: ${item.stock}',
                  ),
                  trailing: Text('${item.sellingPrice} TZS'),
                  onTap: () {
                    Navigator.pop(context, item);
                  },
                );
              },
            ),
    );
  }
}
