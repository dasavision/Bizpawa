import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:bizpawa/core/state/business_state.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    final business = context.watch<BusinessState>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashibodi'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// ================= MAUZO YA LEO =================
            _TodaySalesCard(
              amount: business.todaySales,
              changePercent: business.todaySalesChangePercent,
            ),

            const SizedBox(height: 16),

            /// ================= PROFIT & STOCK VALUE =================
            Row(
              children: [
                Expanded(
                  child: _InfoCard(
                    title: 'Faida',
                    value: '${business.netProfit} TZS',
                    color: const Color(0xFF22C55E),
                    icon: Icons.trending_up,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _InfoCard(
                    title: 'Thamani ya Stock',
                    value: '${business.totalStockValue} TZS',
                    color: const Color(0xFF6366F1),
                    icon: Icons.inventory,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            /// ================= STOCK INSIGHTS =================
            const Text(
              'Taarifa za Stock',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),

            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: _MiniCard(
                    title: 'Low Stock',
                    value: business.lowStockCount.toString(),
                    color: const Color(0xFFF97316),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _MiniCard(
                    title: 'Expiring Soon',
                    value: business.expiringSoonCount.toString(),
                    color: const Color(0xFFEF4444),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _MiniCard(
                    title: 'Fast Moving',
                    value: business.fastMovingCount.toString(),
                    color: const Color(0xFF0EA5E9),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// =======================================================
/// 1️⃣ TODAY SALES CARD
/// =======================================================
class _TodaySalesCard extends StatelessWidget {
  final int amount;
  final double changePercent;

  const _TodaySalesCard({
    required this.amount,
    required this.changePercent,
  });

  @override
  Widget build(BuildContext context) {
    final isUp = changePercent >= 0;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF2563EB),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Mauzo ya Leo',
            style: TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 8),
          Text(
            '$amount TZS',
            style: const TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(
                isUp ? Icons.arrow_upward : Icons.arrow_downward,
                color: Colors.white,
                size: 16,
              ),
              const SizedBox(width: 4),
              Text(
                '${changePercent.abs().toStringAsFixed(1)}%',
                style: const TextStyle(color: Colors.white),
              ),
              const SizedBox(width: 6),
              const Text(
                'kuliko jana',
                style: TextStyle(color: Colors.white70),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// =======================================================
/// 2️⃣ INFO CARD (Faida / Thamani ya Stock)
/// =======================================================
class _InfoCard extends StatelessWidget {
  final String title;
  final String value;
  final Color color;
  final IconData icon;

  const _InfoCard({
    required this.title,
    required this.value,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color),
          const SizedBox(height: 12),
          Text(
            title,
            style: TextStyle(color: color),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }
}

/// =======================================================
/// 3️⃣ MINI CARD (Low / Expiring / Fast)
/// =======================================================
class _MiniCard extends StatelessWidget {
  final String title;
  final String value;
  final Color color;

  const _MiniCard({
    required this.title,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: const TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }
}
