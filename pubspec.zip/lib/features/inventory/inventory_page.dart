import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:bizpawa/core/state/business_state.dart';
import 'add_product_page.dart';
import 'add_service_page.dart';
import 'edit_product_page.dart';

enum InventoryFilter {
  available,
  lowStock,
  outOfStock,
  expiringSoon,
}

class InventoryPage extends StatefulWidget {
  const InventoryPage({super.key});

  @override
  State<InventoryPage> createState() => _InventoryPageState();
}

class _InventoryPageState extends State<InventoryPage> {
  InventoryFilter _currentFilter = InventoryFilter.available;
  String _searchQuery = '';

  @override
  Widget build(BuildContext context) {
    final business = context.watch<BusinessState>();

    /// ✅ FILTER + SEARCH
    final filteredItems = business.inventory.where((item) {
      final matchesSearch =
          item.name.toLowerCase().contains(_searchQuery.toLowerCase());

      bool matchesFilter = true;

      switch (_currentFilter) {
        case InventoryFilter.available:
          matchesFilter = item.unit == 'SERVICE' || item.stock > 0;
          break;

        case InventoryFilter.lowStock:
          matchesFilter =
              item.unit != 'SERVICE' && item.stock > 0 && item.stock <= 5;
          break;

        case InventoryFilter.outOfStock:
          matchesFilter = item.unit != 'SERVICE' && item.stock == 0;
          break;

        case InventoryFilter.expiringSoon:
          if (item.expiryDate == null) return false;
          final days =
              item.expiryDate!.difference(DateTime.now()).inDays;
          matchesFilter = days >= 0 && days <= 5;
          break;
      }

      return matchesSearch && matchesFilter;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Bidhaa / Stock'),
      ),
      body: Column(
        children: [
          /// 🔍 SEARCH
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Tafuta Bidhaa',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onChanged: (v) => setState(() => _searchQuery = v),
            ),
          ),

          /// 🏷 FILTERS
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                _filterChip('Zilizopo', InventoryFilter.available),
                _filterChip('Karibia Kuisha', InventoryFilter.lowStock),
                _filterChip('Zilizoisha', InventoryFilter.outOfStock),
                _filterChip('Karibia Kuharibika', InventoryFilter.expiringSoon),
              ],
            ),
          ),

          const SizedBox(height: 16),

          /// 📊 SUMMARY
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                _summaryCard(
                  'Bidhaa',
                  business.totalItemsCount.toString(),
                  Colors.green.shade100,
                ),
                const SizedBox(width: 8),
                _summaryCard(
                  'Kununua',
                  '${business.totalBuyingStockValue} TZS',
                  Colors.orange.shade100,
                ),
                const SizedBox(width: 8),
                _summaryCard(
                  'Kuuza',
                  '${business.totalSellingStockValue} TZS',
                  Colors.purple.shade100,
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          /// ➕ ADD
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.add),
                label: const Text('Ongeza'),
                onPressed: () => _showAddOptions(context),
              ),
            ),
          ),

          const SizedBox(height: 8),

          /// 📦 LIST
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: filteredItems.length,
              itemBuilder: (context, index) {
                final item = filteredItems[index];
                final isService = item.unit == 'SERVICE';

                Color statusColor() {
                  if (isService) return Colors.blue;
                  if (item.stock == 0) return Colors.red;
                  if (item.stock <= 5) return Colors.orange;
                  return Colors.green;
                }

                String statusText() {
                  if (isService) return 'HUDUMA';
                  if (item.stock == 0) return 'IMEISHA';
                  if (item.stock <= 5) return 'KARIBIA';
                  return 'IPO';
                }

                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            EditProductPage(product: item),
                      ),
                    );
                  },
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.05),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        /// IMAGE / ICON
                        Container(
                          height: 56,
                          width: 56,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.grey.shade200,
                            image: item.imagePath != null
                                ? DecorationImage(
                                    image: FileImage(
                                      File(item.imagePath!),
                                    ),
                                    fit: BoxFit.cover,
                                  )
                                : null,
                          ),
                          child: item.imagePath == null
                              ? Icon(
                                  isService
                                      ? Icons.handyman
                                      : Icons.inventory_2,
                                  color: Colors.grey,
                                )
                              : null,
                        ),

                        const SizedBox(width: 12),

                        /// INFO
                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              Text(
                                item.name,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                isService
                                    ? 'Huduma'
                                    : '${item.stock} ${item.unit}',
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: Colors.black54,
                                ),
                              ),
                            ],
                          ),
                        ),

                        /// STATUS + PRICE
                        Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.end,
                          children: [
                            Container(
                              padding:
                                  const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: statusColor()
                                    .withValues(alpha: 0.15),
                                borderRadius:
                                    BorderRadius.circular(8),
                              ),
                              child: Text(
                                statusText(),
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  color: statusColor(),
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              '${item.sellingPrice} TZS',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  /// ================= FILTER CHIP =================
  Widget _filterChip(String label, InventoryFilter filter) {
    final selected = _currentFilter == filter;

    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _currentFilter = filter),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 4),
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: selected ? Colors.blue : Colors.transparent,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.blue),
          ),
          child: Center(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 11,
                color: selected ? Colors.white : Colors.blue,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// ================= SUMMARY CARD =================
  Widget _summaryCard(String title, String value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 12)),
            const SizedBox(height: 4),
            Text(
              value,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// ================= ADD OPTIONS =================
  void _showAddOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius:
            BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.inventory_2),
                title: const Text('Ongeza Bidhaa'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          const AddProductPage(),
                    ),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.handyman),
                title: const Text('Ongeza Huduma'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          const AddServicePage(),
                    ),
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }
}
