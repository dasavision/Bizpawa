import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import 'package:bizpawa/models/product.dart';
import 'package:bizpawa/core/state/business_state.dart';

class EditProductPage extends StatefulWidget {
  final Product product;

  const EditProductPage({
    super.key,
    required this.product,
  });

  @override
  State<EditProductPage> createState() => _EditProductPageState();
}

class _EditProductPageState extends State<EditProductPage> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _name;
  late TextEditingController _buyingPrice;
  late TextEditingController _sellingPrice;
  late TextEditingController _addStock;

  late String _selectedCategory;
  late String _selectedUnit;
  String? _imagePath;

  static const List<String> _units = [
    'PCS',
    'KG',
    'BOX',
    'LTR',
    'SERVICE',
  ];

  @override
  void initState() {
    super.initState();

    _name = TextEditingController(text: widget.product.name);
    _buyingPrice =
        TextEditingController(text: widget.product.buyingPrice.toString());
    _sellingPrice =
        TextEditingController(text: widget.product.sellingPrice.toString());
    _addStock = TextEditingController();

    _imagePath = widget.product.imagePath;

    /// ✅ SAFE UNIT
    if (_units.contains(widget.product.unit)) {
      _selectedUnit = widget.product.unit;
    } else {
      _selectedUnit = 'PCS';
    }

    /// CATEGORY itarekebishwa kwenye build
    _selectedCategory = widget.product.category;
  }

  @override
  void dispose() {
    _name.dispose();
    _buyingPrice.dispose();
    _sellingPrice.dispose();
    _addStock.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      setState(() => _imagePath = image.path);
    }
  }

  @override
  Widget build(BuildContext context) {
    final business = context.watch<BusinessState>();
    final categories = business.categories;

    /// ✅ SAFE CATEGORY (HII NDIO FIX KUU)
    if (!categories.contains(_selectedCategory)) {
      _selectedCategory = categories.first;
    }

    final isService = _selectedUnit == 'SERVICE';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Hariri Bidhaa'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete, color: Colors.red),
            onPressed: () {
              business.deleteProductById(widget.product.id);
              Navigator.pop(context);
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              /// ================= IMAGE PICKER =================
              GestureDetector(
                onTap: _pickImage,
                child: Container(
                  height: 120,
                  width: 120,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(12),
                    image: _imagePath != null
                        ? DecorationImage(
                            image: FileImage(File(_imagePath!)),
                            fit: BoxFit.cover,
                          )
                        : null,
                  ),
                  child: _imagePath == null
                      ? const Icon(Icons.camera_alt, size: 32)
                      : null,
                ),
              ),

              const SizedBox(height: 24),

              /// ================= NAME =================
              TextFormField(
                controller: _name,
                decoration:
                    const InputDecoration(labelText: 'Jina la bidhaa'),
                validator: (v) =>
                    v == null || v.isEmpty ? 'Jina linahitajika' : null,
              ),

              const SizedBox(height: 12),

              /// ================= CATEGORY =================
              DropdownButtonFormField<String>(
                value: _selectedCategory,
                decoration:
                    const InputDecoration(labelText: 'Kundi la bidhaa'),
                items: categories
                    .map(
                      (c) => DropdownMenuItem(
                        value: c,
                        child: Text(c),
                      ),
                    )
                    .toList(),
                onChanged: (v) {
                  if (v != null) {
                    setState(() => _selectedCategory = v);
                  }
                },
              ),

              const SizedBox(height: 12),

              /// ================= UNIT =================
              DropdownButtonFormField<String>(
                value: _selectedUnit,
                decoration:
                    const InputDecoration(labelText: 'Packaging / Unit'),
                items: _units
                    .map(
                      (u) => DropdownMenuItem(
                        value: u,
                        child: Text(u == 'SERVICE' ? 'Huduma' : u),
                      ),
                    )
                    .toList(),
                onChanged: (v) {
                  if (v != null) {
                    setState(() => _selectedUnit = v);
                  }
                },
              ),

              const SizedBox(height: 12),

              /// ================= BUYING PRICE =================
              TextFormField(
                controller: _buyingPrice,
                keyboardType: TextInputType.number,
                decoration:
                    const InputDecoration(labelText: 'Bei ya kununua'),
              ),

              const SizedBox(height: 12),

              /// ================= SELLING PRICE =================
              TextFormField(
                controller: _sellingPrice,
                keyboardType: TextInputType.number,
                decoration:
                    const InputDecoration(labelText: 'Bei ya kuuza'),
              ),

              if (!isService) ...[
                const SizedBox(height: 16),
                const Divider(),

                /// ================= ADD STOCK =================
                TextFormField(
                  controller: _addStock,
                  keyboardType: TextInputType.number,
                  decoration:
                      const InputDecoration(labelText: 'Ongeza stock'),
                ),
              ],

              const SizedBox(height: 24),

              /// ================= SAVE =================
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  child: const Text('Hifadhi Mabadiliko'),
                  onPressed: () {
                    if (!_formKey.currentState!.validate()) return;

                    final addedStock =
                        int.tryParse(_addStock.text) ?? 0;

                    final updated = Product(
                      id: widget.product.id,
                      name: _name.text.trim(),
                      category: _selectedCategory,
                      unit: _selectedUnit,
                      buyingPrice:
                          int.tryParse(_buyingPrice.text) ?? 0,
                      sellingPrice:
                          int.tryParse(_sellingPrice.text) ?? 0,
                      stock: isService
                          ? widget.product.stock
                          : widget.product.stock + addedStock,
                      imagePath: _imagePath,
                      description: widget.product.description,
                    );

                    business.updateProduct(updated);
                    Navigator.pop(context);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
