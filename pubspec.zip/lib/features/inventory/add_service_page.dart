import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import 'package:bizpawa/core/state/business_state.dart';
import 'package:bizpawa/models/product.dart';

class AddServicePage extends StatefulWidget {
  const AddServicePage({super.key});

  @override
  State<AddServicePage> createState() => _AddServicePageState();
}

class _AddServicePageState extends State<AddServicePage> {
  final _formKey = GlobalKey<FormState>();

  final _nameController = TextEditingController();
  final _priceController = TextEditingController();
  final _descriptionController = TextEditingController();

  bool _showDescription = false;
  String? _imagePath;

  Future<void> _pickImage() async {
    final image = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() => _imagePath = image.path);
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _priceController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final business = context.read<BusinessState>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ongeza Huduma'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /// ================= IMAGE (OPTIONAL) =================
              GestureDetector(
                onTap: _pickImage,
                child: Container(
                  height: 110,
                  width: 110,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(12),
                    image: _imagePath != null
                        ? DecorationImage(
                            image: FileImage(File(_imagePath!)),
                            fit: BoxFit.cover,
                          )
                        : null,
                  ),
                  child: _imagePath == null
                      ? const Icon(Icons.camera_alt_outlined)
                      : null,
                ),
              ),

              const SizedBox(height: 24),

              /// ================= NAME =================
              TextFormField(
                controller: _nameController,
                decoration:
                    const InputDecoration(labelText: 'Jina la huduma'),
                validator: (v) =>
                    v == null || v.isEmpty ? 'Jina linahitajika' : null,
              ),

              const SizedBox(height: 16),

              /// ================= PRICE =================
              TextFormField(
                controller: _priceController,
                keyboardType: TextInputType.number,
                decoration:
                    const InputDecoration(labelText: 'Bei ya huduma'),
                validator: (v) =>
                    v == null || v.isEmpty ? 'Bei inahitajika' : null,
              ),

              const SizedBox(height: 16),

              /// ================= OPTIONAL DESCRIPTION =================
              TextButton.icon(
                icon: Icon(
                  _showDescription ? Icons.remove : Icons.add,
                ),
                label: const Text('Maelezo ya ziada (hiari)'),
                onPressed: () {
                  setState(() => _showDescription = !_showDescription);
                },
              ),

              if (_showDescription)
                TextFormField(
                  controller: _descriptionController,
                  maxLines: 3,
                  decoration:
                      const InputDecoration(labelText: 'Maelezo'),
                ),

              const SizedBox(height: 32),

              /// ================= SAVE =================
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  child: const Text('Hifadhi Huduma'),
                  onPressed: () {
                    if (!_formKey.currentState!.validate()) return;

                    final service = Product(
                      id: DateTime.now()
                          .millisecondsSinceEpoch
                          .toString(),
                      name: _nameController.text.trim(),
                      category: 'SERVICE',
                      unit: 'SERVICE',
                      buyingPrice: 0,
                      sellingPrice:
                          int.tryParse(_priceController.text) ?? 0,
                      stock: 0,
                      imagePath: _imagePath,
                      description:
                          _descriptionController.text.trim(),
                    );

                    business.addProduct(service);
                    Navigator.pop(context);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
