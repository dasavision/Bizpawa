import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import 'package:bizpawa/core/state/business_state.dart';
import 'package:bizpawa/models/product.dart';

class AddProductPage extends StatefulWidget {
  const AddProductPage({super.key});

  @override
  State<AddProductPage> createState() => _AddProductPageState();
}

class _AddProductPageState extends State<AddProductPage> {
  final _formKey = GlobalKey<FormState>();

  final _nameController = TextEditingController();
  final _stockController = TextEditingController();
  final _buyingPriceController = TextEditingController();
  final _sellingPriceController = TextEditingController();
  final _descriptionController = TextEditingController();

  String? _selectedCategory;
  String? _selectedPackaging;
  DateTime? _expiryDate;
  String? _imagePath;

  final packagingOptions = const [
    'Piece',
    'Pcs',
    'Pack',
    'Packet',
    'Box',
    'Carton',
    'Bottle',
    'Can',
    'Bag',
    'Jar',
    'Tube',
    'Roll',
    'Bundle',
    'Set',
    'Kg',
    'Litre',
    'Dozen',
    'Tray',
    'Others',
  ];

  Future<void> _pickImage() async {
    final image = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() => _imagePath = image.path);
    }
  }

  Future<void> _pickExpiryDate() async {
    final date = await showDatePicker(
      context: context,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365 * 5)),
      initialDate: DateTime.now(),
    );

    if (date != null) {
      setState(() => _expiryDate = date);
    }
  }

  void _createCategoryDialog(BusinessState business) {
    final controller = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Tengeneza Kundi Jipya'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(
            hintText: 'Mf. Bidhaa Stationery',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Ghairi'),
          ),
          ElevatedButton(
            onPressed: () {
              final value = controller.text.trim();
              if (value.isNotEmpty) {
                setState(() => _selectedCategory = value);
              }
              Navigator.pop(context);
            },
            child: const Text('Hifadhi'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final business = context.watch<BusinessState>();
    final categories = business.categories;

    return Scaffold(
      appBar: AppBar(title: const Text('Ongeza Bidhaa Mpya')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /// IMAGE
              GestureDetector(
                onTap: _pickImage,
                child: Container(
                  height: 110,
                  width: 110,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(12),
                    image: _imagePath != null
                        ? DecorationImage(
                            image: FileImage(File(_imagePath!)),
                            fit: BoxFit.cover,
                          )
                        : null,
                  ),
                  child: _imagePath == null
                      ? const Icon(Icons.camera_alt)
                      : null,
                ),
              ),

              const SizedBox(height: 20),

              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(labelText: 'Jina la bidhaa'),
                validator: (v) =>
                    v == null || v.isEmpty ? 'Jina linahitajika' : null,
              ),

              const SizedBox(height: 12),

              /// CATEGORY
              DropdownButtonFormField<String>(
                value: _selectedCategory,
                hint: const Text('Chagua Kundi'),
                items: categories
                    .map(
                      (c) => DropdownMenuItem(
                        value: c,
                        child: Text(c),
                      ),
                    )
                    .toList(),
                onChanged: (v) => setState(() => _selectedCategory = v),
                validator: (v) =>
                    v == null ? 'Chagua au tengeneza kundi' : null,
              ),

              const SizedBox(height: 8),

              OutlinedButton.icon(
                icon: const Icon(Icons.add),
                label: const Text('Tengeneza Kundi Jipya'),
                onPressed: () => _createCategoryDialog(business),
              ),

              const SizedBox(height: 16),

              /// PACKAGING
              DropdownButtonFormField<String>(
                value: _selectedPackaging,
                hint: const Text('Chagua Kifungashio'),
                items: packagingOptions
                    .map(
                      (p) => DropdownMenuItem(
                        value: p,
                        child: Text(p),
                      ),
                    )
                    .toList(),
                onChanged: (v) => setState(() => _selectedPackaging = v),
                validator: (v) =>
                    v == null ? 'Chagua kifungashio' : null,
              ),

              const SizedBox(height: 12),

              TextFormField(
                controller: _stockController,
                keyboardType: TextInputType.number,
                decoration:
                    const InputDecoration(labelText: 'Idadi ya kuanzia'),
              ),

              const SizedBox(height: 12),

              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _buyingPriceController,
                      keyboardType: TextInputType.number,
                      decoration:
                          const InputDecoration(labelText: 'Bei ya kununua'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _sellingPriceController,
                      keyboardType: TextInputType.number,
                      decoration:
                          const InputDecoration(labelText: 'Bei ya kuuza'),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              TextButton.icon(
                icon: const Icon(Icons.date_range),
                label: Text(
                  _expiryDate == null
                      ? 'Ongeza tarehe ya ku-expire (hiari)'
                      : 'Expire: ${_expiryDate!.toLocal().toString().split(' ')[0]}',
                ),
                onPressed: _pickExpiryDate,
              ),

              const SizedBox(height: 24),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  child: const Text('Hifadhi Bidhaa'),
                  onPressed: () {
                    if (!_formKey.currentState!.validate()) return;

                    final product = Product(
                      id: DateTime.now()
                          .millisecondsSinceEpoch
                          .toString(),
                      name: _nameController.text.trim(),
                      category: _selectedCategory!,
                      unit: _selectedPackaging!,
                      buyingPrice:
                          int.tryParse(_buyingPriceController.text) ?? 0,
                      sellingPrice:
                          int.tryParse(_sellingPriceController.text) ?? 0,
                      stock: int.tryParse(_stockController.text) ?? 0,
                      expiryDate: _expiryDate,
                      imagePath: _imagePath,
                      description: _descriptionController.text.trim(),
                    );

                    business.addProduct(product);
                    Navigator.pop(context);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
