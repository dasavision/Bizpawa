class Product {
  final String id;
  final String name;
  final String category;
  final String unit;
  final int buyingPrice;
  final int sellingPrice;
  int stock;
  final String? imagePath;
  final String? description;
  final DateTime? expiryDate;

  Product({
    required this.id,
    required this.name,
    required this.category,
    required this.unit,
    required this.buyingPrice,
    required this.sellingPrice,
    required this.stock,
    this.imagePath,
    this.description,
    this.expiryDate,
  });
}
