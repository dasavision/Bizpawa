import 'package:flutter/material.dart';
import 'package:bizpawa/models/product.dart';
import 'package:bizpawa/models/sale_order.dart';
import 'package:bizpawa/models/sale_item.dart';


enum SalesFilter { today, week, custom }

class BusinessState extends ChangeNotifier {
  /// ================== DASHBOARD ==================
  int todaySales = 0;
  int netProfit = 0;
  int expenses = 0;

  /// ================== SALES ==================
final List<SaleOrder> _orders = [];

List<SaleOrder> get orders =>
    _orders.reversed.toList(); // latest first

SaleOrder? _draftOrder;
SaleOrder? get draftOrder => _draftOrder;

/// ▶️ START NEW SALE
void startNewSale({String seller = 'Admin'}) {
  _draftOrder = SaleOrder(
    id: DateTime.now().millisecondsSinceEpoch.toString(),
    date: DateTime.now(),
    sellerName: seller,
  );
  notifyListeners();
}

/// ➕ ADD ITEM TO SALE
void addItemToSale(SaleItem item) {
  if (_draftOrder == null) return;

  final index = _draftOrder!.items.indexWhere(
    (i) => i.product.id == item.product.id,
  );

  if (index != -1) {
    _draftOrder!.items[index].quantity += item.quantity;
  } else {
    _draftOrder!.items.add(item);
  }

  notifyListeners();
}

/// ➕ / ➖ UPDATE QUANTITY
void updateItemQuantity(String productId, int qty) {
  if (_draftOrder == null) return;

  final index = _draftOrder!.items
      .indexWhere((i) => i.product.id == productId);

  if (index == -1) return;

  if (qty <= 0) {
    _draftOrder!.items.removeAt(index);
  } else {
    _draftOrder!.items[index].quantity = qty;
  }

  notifyListeners();
}

/// 🏷 DISCOUNT
void setDiscount(int amount) {
  if (_draftOrder == null) return;
  _draftOrder!.discount = amount;
  notifyListeners();
}

/// 🧾 NOTES
void setSaleNotes(String notes) {
  if (_draftOrder == null) return;
  _draftOrder!.notes = notes;
  notifyListeners();
}

/// 👤 CUSTOMER
void setCustomer(String name) {
  if (_draftOrder == null) return;
  _draftOrder!.customerName = name;
  notifyListeners();
}

/// 💾 SAVE SALE
bool completeSale({
  required PaymentStatus status,
  PaymentMethod? method,
}) {
  if (_draftOrder == null) return false;

  /// ❗ MKOPO: mteja lazima
  if (status == PaymentStatus.unpaid &&
      (_draftOrder!.customerName == null ||
          _draftOrder!.customerName!.isEmpty)) {
    return false;
  }

  _draftOrder!
    ..status = status
    ..paymentMethod = method;

  /// 🔻 Punguza stock kwa bidhaa tu
  for (final item in _draftOrder!.items) {
    if (item.product.unit != 'SERVICE') {
      item.product.stock -= item.quantity;
    }
  }

  _orders.add(_draftOrder!);
  _draftOrder = null;

  notifyListeners();
  return true;
}


  /// ================== INVENTORY ==================
  final List<Product> inventory = [];

  void addProduct(Product product) {
    inventory.add(product);
    notifyListeners();
  }

  void addService(Product service) {
    inventory.add(service);
    notifyListeners();
  }

  void updateProduct(Product updated) {
    final index = inventory.indexWhere((p) => p.id == updated.id);
    if (index != -1) {
      inventory[index] = updated;
      notifyListeners();
    }
  }

  /// ✅ FIXED: delete by ID
  void deleteProductById(String productId) {
    inventory.removeWhere((p) => p.id == productId);
    notifyListeners();
  }

  void addStock(Product product, int quantity) {
    if (product.unit == 'SERVICE') return;

    final index = inventory.indexWhere((p) => p.id == product.id);
    if (index != -1) {
      inventory[index].stock += quantity;
      notifyListeners();
    }
  }

  /// ================== CATEGORIES ==================
  /// 👉 Auto-generated kutoka inventory
  List<String> get categories {
    final set = <String>{};
    for (final p in inventory) {
      if (p.category.trim().isNotEmpty) {
        set.add(p.category);
      }
    }
    return set.isEmpty ? ['General'] : set.toList();
  }

  /// ================== SALES ==================
  final List<SaleEntry> _salesHistory = [];
  List<SaleEntry> get salesHistory => _salesHistory;

  void recordSale({
    required Product product,
    required int quantity,
    required int discount,
    required DateTime date,
    required bool paid,
  }) {
    if (product.unit != 'SERVICE' && quantity > product.stock) return;

    if (product.unit != 'SERVICE') {
      product.stock -= quantity;
    }

    final amount = (product.sellingPrice * quantity) - discount;

    todaySales += amount;
    netProfit += (amount * 0.3).toInt();

    _salesHistory.insert(
      0,
      SaleEntry(
        productName: product.name,
        amount: amount,
        date: date,
      ),
    );

    notifyListeners();
  }

  /// ================== DASHBOARD LOGIC ==================
  double get todaySalesChangePercent {
    final today = DateTime.now();
    final yesterday = today.subtract(const Duration(days: 1));

    int todayTotal = 0;
    int yesterdayTotal = 0;

    for (final sale in _salesHistory) {
      if (_isSameDay(sale.date, today)) {
        todayTotal += sale.amount;
      } else if (_isSameDay(sale.date, yesterday)) {
        yesterdayTotal += sale.amount;
      }
    }

    if (yesterdayTotal == 0) {
      return todayTotal > 0 ? 100 : 0;
    }

    return ((todayTotal - yesterdayTotal) / yesterdayTotal) * 100;
  }

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  /// ================== STOCK INSIGHTS ==================
  int get lowStockCount =>
      inventory.where((p) => p.unit != 'SERVICE' && p.stock <= 5).length;

  int get expiringSoonCount =>
      inventory.where((p) {
        if (p.expiryDate == null) return false;
        final days = p.expiryDate!.difference(DateTime.now()).inDays;
        return days >= 0 && days <= 5;
      }).length;

  int get fastMovingCount =>
      _salesHistory.where(
        (s) => DateTime.now().difference(s.date).inDays <= 7,
      ).length;

  /// ================== INVENTORY SUMMARY ==================
  int get totalItemsCount => inventory.length;

  int get totalBuyingStockValue {
    int total = 0;
    for (final p in inventory) {
      total += p.unit == 'SERVICE'
          ? p.buyingPrice
          : p.buyingPrice * p.stock;
    }
    return total;
  }

  int get totalSellingStockValue {
    int total = 0;
    for (final p in inventory) {
      total += p.unit == 'SERVICE'
          ? p.sellingPrice
          : p.sellingPrice * p.stock;
    }
    return total;
  }

  int get totalStockValue => totalSellingStockValue;
}

/// ================== SALE MODEL ==================
class SaleEntry {
  final String productName;
  final int amount;
  final DateTime date;

  SaleEntry({
    required this.productName,
    required this.amount,
    required this.date,
  });
}
