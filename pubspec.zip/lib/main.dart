import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/state/business_state.dart';
import 'core/app_shell.dart';
import 'features/inventory/add_product_page.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => BusinessState(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const AppShell(),
      routes: {
        '/add-product': (_) => const AddProductPage(),
      },
    );
  }
}
